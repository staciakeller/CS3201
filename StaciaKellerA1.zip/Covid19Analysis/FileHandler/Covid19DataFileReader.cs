﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using Windows.Storage;
using Covid19Analysis.Model;

namespace Covid19Analysis.FileHandler
{
    internal class Covid19DataFileReader
    {
        #region Properties

        public Covid19DataCollection LoadedData { get; }

        #endregion

        #region Constructors

        /// <summary>Initializes a new instance of the <a onclick="return false;" href="Covid19DataFileReader" originaltag="see">Covid19DataFileReader</a> class.</summary>
        public Covid19DataFileReader()
        {
            this.LoadedData = new Covid19DataCollection();
        }

        #endregion

        #region Methods

        /// <summary>Reads the file.</summary>
        /// <param name="file">The file.</param>
        public async Task ReadFile(StorageFile file)
        {
            if (file == null)
            {
                throw new ArgumentNullException(nameof(file), "File cannot be null");
            }
            var allText = await FileIO.ReadTextAsync(file);
            var modifiedText = allText.Replace("\r", "");

            var lines = modifiedText.Split("\n");

            foreach (var aLine in lines)
            {
                if (!aLine.StartsWith("2020"))
                {
                    continue;
                }

                var aDataSet = aLine.Split(",");
                var date = DateTime.ParseExact(aDataSet.GetValue(0).ToString(), "yyyyMMdd",
                    CultureInfo.InvariantCulture);
                var state = Enum.Parse<StateAbbreviations>(aDataSet.GetValue(1).ToString());
                var posInc = int.Parse(aDataSet.GetValue(2).ToString());
                var negInc = int.Parse(aDataSet.GetValue(3).ToString());
                var deaths = int.Parse(aDataSet.GetValue(4).ToString());
                var hospital = int.Parse(aDataSet.GetValue(5).ToString());

                var dailyData = new Covid19DailyData(date, state, posInc, negInc, deaths, hospital);
                this.LoadedData.AddDailyData(dailyData);
            }
        }

        #endregion
    }
}