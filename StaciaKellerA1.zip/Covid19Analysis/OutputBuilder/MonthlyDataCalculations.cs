﻿using System;
using Covid19Analysis.Model;

namespace Covid19Analysis.OutputBuilder
{
    internal class MonthlyDataCalculations
    {
        #region Data members

        public Covid19DataCollection MonthlyData = new Covid19DataCollection();

        #endregion

        #region Properties

        public int Month { get; set; }

        /// <summary>Gets or sets the data to format.</summary>
        /// <value>The data to format.</value>
        public Covid19DataCollection DataToFormat { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the
        ///     <a onclick="return false;" href="MonthlyDataCollector" originaltag="see">MonthlyDataCollector</a> class.
        /// </summary>
        /// <param name="month">The month.</param>
        /// <param name="dataToFormat">The data to format.</param>
        /// <exception cref="ArgumentNullException">dataToFormat</exception>
        public MonthlyDataCalculations(int month, Covid19DataCollection dataToFormat)
        {
            this.Month = month;
            this.DataToFormat = dataToFormat ?? throw new ArgumentNullException(nameof(dataToFormat));
            foreach (Covid19DailyData currData in this.DataToFormat)
            {
                if (currData.DataDate.Month == month)
                {
                    this.MonthlyData.AddDailyData(currData);
                }
            }
        }

        #endregion

        #region Methods

        public Covid19DailyData DataOfHightestPositive()
        {
            var highestPos = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.MonthlyData)
            {
                if (currData.PositiveIncrease > highestPos)
                {
                    highestPos = currData.PositiveIncrease;
                    dataWithHighest = currData;
                }
            }

            this.MonthlyData.Reset();

            return dataWithHighest;
        }

        public Covid19DailyData DataOfLowestPositive()
        {
            var lowestPos = int.MaxValue;
            Covid19DailyData dataWithLowest = null;
            foreach (Covid19DailyData currData in this.MonthlyData)
            {
                if (currData.PositiveIncrease < lowestPos)
                {
                    lowestPos = currData.PositiveIncrease;
                    dataWithLowest = currData;
                }
            }

            this.MonthlyData.Reset();

            return dataWithLowest;
        }

        public Covid19DailyData DataOfLowestTests()
        {
            var lowestPos = int.MaxValue;
            Covid19DailyData dataWithLowest = null;
            foreach (Covid19DailyData currData in this.MonthlyData)
            {
                if (currData.TotalTest < lowestPos)
                {
                    lowestPos = currData.TotalTest;
                    dataWithLowest = currData;
                }
            }

            this.MonthlyData.Reset();

            return dataWithLowest;
        }

        public Covid19DailyData DataOfHightestTests()
        {
            var highestPos = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.MonthlyData)
            {
                if (currData.TotalTest > highestPos)
                {
                    highestPos = currData.TotalTest;
                    dataWithHighest = currData;
                }
            }

            this.MonthlyData.Reset();

            return dataWithHighest;
        }

        public int AverageNumberPositive()
        {
            var positiveTests = 0;
            var daysSinceFirstTest = 0;
            foreach (Covid19DailyData currData in this.MonthlyData)
            {
                positiveTests += currData.PositiveIncrease;
                daysSinceFirstTest++;
            }

            this.MonthlyData.Reset();
            if (daysSinceFirstTest != 0)
            {
                return positiveTests / daysSinceFirstTest;
            }

            return 0;
        }

        public int AverageNumberTests()
        {
            var totalTests = 0;
            var daysSinceFirstTest = 0;
            foreach (Covid19DailyData currData in this.MonthlyData)
            {
                totalTests += currData.TotalTest;
                daysSinceFirstTest++;
            }

            this.MonthlyData.Reset();
            if (daysSinceFirstTest != 0)
            {
                return totalTests / daysSinceFirstTest;
            }

            return 0;
        }

        #endregion
    }
}