﻿using System;
using Covid19Analysis.Model;

namespace Covid19Analysis.OutputBuilder
{
    internal class StateDataCalculations
    {
        #region Properties

        public Covid19DataCollection DataToAnalyze { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the
        ///     <a onclick="return false;" href="StateDataCalculations" originaltag="see">StateDataCalculations</a> class.
        /// </summary>
        /// <param name="dataToAnalyze">The data to analyze.</param>
        /// <exception cref="ArgumentNullException">dataToAnalyze</exception>
        public StateDataCalculations(Covid19DataCollection dataToAnalyze)
        {
            this.DataToAnalyze = dataToAnalyze ?? throw new ArgumentNullException(nameof(dataToAnalyze));
            this.DataToAnalyze.Covid19Data.Sort();
        }

        #endregion

        #region Methods

        public DateTime DateOfFirstPositive()
        {
            var data = this.DataToAnalyze.Covid19Data;
            var theDataItem = data.Find(x => x.PositiveIncrease > 0);
            return theDataItem.DataDate;
        }

        public DateTime DateOfLastTest()
        {
            var data = this.DataToAnalyze.Covid19Data;
            var theDataItem = data[data.Count - 1];
            return theDataItem.DataDate;
        }

        public Covid19DailyData DataWithHighestNumberOfPositives()
        {
            var highestPositive = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.PositiveIncrease > highestPositive)
                {
                    highestPositive = currData.PositiveIncrease;
                    dataWithHighest = currData;
                }
            }

            this.DataToAnalyze.Reset();

            return dataWithHighest;
        }

        public Covid19DailyData DataWithHighestNumberOfNegatives()
        {
            var highestNegative = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.NegativeIncrease > highestNegative)
                {
                    highestNegative = currData.NegativeIncrease;
                    dataWithHighest = currData;
                }
            }

            this.DataToAnalyze.Reset();

            return dataWithHighest;
        }

        public Covid19DailyData DataWithHighestNumberTests()
        {
            var highestNum = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.TotalTest > highestNum)
                {
                    highestNum = currData.TotalTest;
                    dataWithHighest = currData;
                }
            }

            this.DataToAnalyze.Reset();

            return dataWithHighest;
        }

        public Covid19DailyData DataWithHighestNumberDeaths()
        {
            var highestNum = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.DeathIncrease > highestNum)
                {
                    highestNum = currData.DeathIncrease;
                    dataWithHighest = currData;
                }
            }

            this.DataToAnalyze.Reset();

            return dataWithHighest;
        }

        public Covid19DailyData DataWithHighestHospitalization()
        {
            var highestNum = int.MinValue;
            Covid19DailyData dataWithHighest = null;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.HospitalizedIncrease > highestNum)
                {
                    highestNum = currData.HospitalizedIncrease;
                    dataWithHighest = currData;
                }
            }

            this.DataToAnalyze.Reset();

            return dataWithHighest;
        }

        public Covid19DailyData DataWithHighestPercentPos()
        {
            var highestPercent = double.MinValue;
            Covid19DailyData highestData = null;

            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.FindPercentPositive() > highestPercent)
                {
                    highestPercent = currData.FindPercentPositive();
                    highestData = currData;
                }
            }

            this.DataToAnalyze.Reset();

            return highestData;
        }

        public int AverageNumberPositiveSinceFirst()
        {
            var positiveTests = 0;
            var daysSinceFirstTest = 0;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.DataDate >= this.DateOfFirstPositive())
                {
                    positiveTests += currData.PositiveIncrease;
                    daysSinceFirstTest++;
                }
            }

            this.DataToAnalyze.Reset();
            if (daysSinceFirstTest != 0)
            {
                return positiveTests / daysSinceFirstTest;
            }

            return 0;
        }

        public double FindPositivityRate()
        {
            double positiveTests = 0;
            double totalTests = 0;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.DataDate >= this.DateOfFirstPositive())
                {
                    positiveTests += currData.PositiveIncrease;
                    totalTests += currData.TotalTest;
                }
            }

            var decimalRate = positiveTests / totalTests;

            this.DataToAnalyze.Reset();

            return decimalRate * 100;
        }

        /// <summary>Numbers the of days with positives greater than.</summary>
        /// <param name="value">The value.</param>
        /// <returns>
        ///  int : number of days <br />
        /// </returns>
        public int NumberOfDaysWithPositivesGreaterThan(int value)
        {
            var daysCounter = 0;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.PositiveIncrease >= value)
                {
                    daysCounter++;
                }
            }

            this.DataToAnalyze.Reset();

            return daysCounter;
        }

        /// <summary>Numbers the of days with positive less than.</summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// int : number of days   <br />
        /// </returns>
        public int NumberOfDaysWithPositiveLessThan(int value)
        {
            var daysCounter = 0;
            foreach (Covid19DailyData currData in this.DataToAnalyze)
            {
                if (currData.DataDate >= this.DateOfFirstPositive() && currData.PositiveIncrease <= value)
                {
                    daysCounter++;
                }
            }

            this.DataToAnalyze.Reset();

            return daysCounter;
        }

        #endregion
    }
}