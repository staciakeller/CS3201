﻿using System;
using System.Globalization;
using Covid19Analysis.Model;

namespace Covid19Analysis.OutputBuilder
{
    internal class DataFormatter
    {
        #region Properties

        public Covid19DataCollection DataToFormat { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the
        ///     <a onclick="return false;" href="DataFormatter" originaltag="see">DataFormatter</a> class.
        /// </summary>
        /// <param name="dataToFormat">The data to format.</param>
        public DataFormatter(Covid19DataCollection dataToFormat)
        {
            this.DataToFormat = dataToFormat;
        }

        #endregion

        #region Methods

        public string FormatStateData()
        {
            var stateDataCalculations = new StateDataCalculations(this.DataToFormat);
            var stateData = "GEORGIA: " + Environment.NewLine;
            stateData +=
                $"First Positive Test occurred on {stateDataCalculations.DateOfFirstPositive().ToShortDateString()}\n";
            var highestPos = stateDataCalculations.DataWithHighestNumberOfPositives();
            stateData +=
                $"Highest Number of Positive Tests was {highestPos.PositiveIncrease} and occurred on {highestPos.DataDate.ToShortDateString()}\n";
            var highestNeg = stateDataCalculations.DataWithHighestNumberOfNegatives();
            stateData +=
                $"Highest Number of Negative Tests was {highestNeg.NegativeIncrease} and occurred on {highestNeg.DataDate.ToShortDateString()}\n";
            var highestTests = stateDataCalculations.DataWithHighestNumberTests();
            stateData +=
                $"Highest Number of Tests was {highestTests.TotalTest} and occurred on {highestTests.DataDate.ToShortDateString()}\n";
            var highestDeaths = stateDataCalculations.DataWithHighestNumberDeaths();
            stateData +=
                $"Highest Number of Deaths was {highestDeaths.DeathIncrease} and occurred on {highestDeaths.DataDate.ToShortDateString()}\n";
            var highestHospital = stateDataCalculations.DataWithHighestHospitalization();
            stateData +=
                $"Highest Number of Hospitalizations was {highestHospital.HospitalizedIncrease} and occurred on {highestHospital.DataDate.ToShortDateString()}\n";
            var highestPercent = stateDataCalculations.DataWithHighestPercentPos();
            stateData +=
                $"Highest Percentage Positive Tests was {highestPercent.FindPercentPositive()}% and occurred on {highestPercent.DataDate.ToShortDateString()}\n";

            stateData +=
                $"Average number of Positive Tests is {stateDataCalculations.AverageNumberPositiveSinceFirst()}\n";
            stateData += $"Positivity Rate of all Tests is {stateDataCalculations.FindPositivityRate()}% \n";
            stateData +=
                $"Number of Days with positives tests greater than 2500 is {stateDataCalculations.NumberOfDaysWithPositivesGreaterThan(2500)}\n";
            stateData +=
                $"Number of Days with positives tests less than 1000 is {stateDataCalculations.NumberOfDaysWithPositiveLessThan(1000)}\n";
            return stateData;
        }

        public string FormatMonthlyData()
        {
            var stateData = new StateDataCalculations(this.DataToFormat);
            var firstMonth = stateData.DateOfFirstPositive().Month;
            var lastMonth = stateData.DateOfLastTest().Month;

            var monthData = "MONTHLY DATA: \n";
            for (var month = firstMonth; month <= lastMonth; month++)
            {
                monthData += CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month) + '\n';

                var monthlyDataCalculations = new MonthlyDataCalculations(month, this.DataToFormat);
                var highestPos = monthlyDataCalculations.DataOfHightestPositive();
                monthData +=
                    $"Highest Number of Positive Tests was {highestPos.PositiveIncrease} and occurred on {highestPos.DataDate.ToShortDateString()}\n";
                var lowestPos = monthlyDataCalculations.DataOfLowestPositive();
                monthData +=
                    $"Lowest Number of Positive Tests was {lowestPos.PositiveIncrease} and occurred on {lowestPos.DataDate.ToShortDateString()}\n";
                var highestTests = monthlyDataCalculations.DataOfHightestTests();
                monthData +=
                    $"Lowest Number of Total Tests was {highestTests.TotalTest} and occurred on {highestTests.DataDate.ToShortDateString()}\n";
                var lowestTest = monthlyDataCalculations.DataOfLowestTests();
                monthData +=
                    $"Highest Number of Total Tests was {lowestTest.TotalTest} and occurred on {lowestTest.DataDate.ToShortDateString()}\n";

                monthData +=
                    $"Average Number of Positive Tests was {monthlyDataCalculations.AverageNumberPositive()}\n";
                monthData += $"Average Number of Total Tests was {monthlyDataCalculations.AverageNumberTests()}\n";
                monthData += Environment.NewLine;
                this.DataToFormat.Reset();
            }

            return monthData;
        }

        #endregion
    }
}