﻿using System;
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Covid19Analysis.FileHandler;
using Covid19Analysis.Model;
using Covid19Analysis.OutputBuilder;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Covid19Analysis
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage
    {
        #region Data members

        /// <summary>
        ///     The application height
        /// </summary>
        public const int ApplicationHeight = 355;

        /// <summary>
        ///     The application width
        /// </summary>
        public const int ApplicationWidth = 625;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="MainPage" /> class.
        /// </summary>
        public MainPage()
        {
            this.InitializeComponent();

            ApplicationView.PreferredLaunchViewSize = new Size {Width = ApplicationWidth, Height = ApplicationHeight};
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(ApplicationWidth, ApplicationHeight));
        }

        #endregion

        #region Methods

        private async void loadFile_Click(object sender, RoutedEventArgs e)
        {
            this.summaryTextBox.Text = "Load file was invoked.";

            var openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
            openPicker.FileTypeFilter.Add(".csv");
            openPicker.FileTypeFilter.Add(".txt");

            var file = await openPicker.PickSingleFileAsync();
            if (file != null)
            {
                this.readAndWriteData(file);
            }
            else
            {
                this.summaryTextBox.Text = "Operation cancelled.";
            }
        }

        private async void readAndWriteData(StorageFile file)
        {
            //this.summaryTextBox.Text = "Picked file: " + file.Name;
            var fileReader = new Covid19DataFileReader();
            await fileReader.ReadFile(file);

            var allLoadedData = fileReader.LoadedData;
            var dataFromSelectedState =
                new Covid19DataCollection(allLoadedData.GetDataFromState(StateAbbreviations.GA));
            var formatter = new DataFormatter(dataFromSelectedState);
            this.summaryTextBox.Text = formatter.FormatStateData() + Environment.NewLine;
            this.summaryTextBox.Text += formatter.FormatMonthlyData();
        }

        #endregion
    }
}