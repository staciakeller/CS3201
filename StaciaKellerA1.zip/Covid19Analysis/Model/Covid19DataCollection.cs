﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Covid19Analysis.Model
{
    internal class Covid19DataCollection : IEnumerator, IEnumerable
    {
        #region Data members

        /// <summary>The position</summary>
        public int Position;

        #endregion

        #region Properties

        /// <summary>Gets or sets the covid19 data.</summary>
        /// <value>The covid19 data.</value>
        public List<Covid19DailyData> Covid19Data { get; set; }

        /// <summary>Gets the element in the collection at the current position of the enumerator.</summary>
        public object Current => this.Covid19Data[this.Position];

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the
        ///     <a onclick="return false;" href="Covid19DataCollection" originaltag="see">Covid19DataCollection</a> class.
        /// </summary>
        public Covid19DataCollection()
        {
            this.Covid19Data = new List<Covid19DailyData>();
        }

        /// <summary>
        ///     Initializes a new instance of the
        ///     <a onclick="return false;" href="Covid19DataCollection" originaltag="see">Covid19DataCollection</a> class.
        /// </summary>
        /// <param name="covid19Data">The covid19 data.</param>
        public Covid19DataCollection(List<Covid19DailyData> covid19Data)
        {
            this.Covid19Data = covid19Data;
        }

        #endregion

        #region Methods

        public IEnumerator GetEnumerator()
        {
            return this;
        }

        public bool MoveNext()
        {
            this.Position++;
            return this.Position < this.Covid19Data.Count;
        }

        public void Reset()
        {
            this.Position = 0;
        }

        public List<Covid19DailyData> GetDataFromState(StateAbbreviations state)
        {
            var aStateCollection = new List<Covid19DailyData>();
            foreach (var currDailyData in this.Covid19Data)
            {
                if (currDailyData.State == StateAbbreviations.GA)
                {
                    aStateCollection.Add(currDailyData);
                }
            }

            return aStateCollection;
        }

        /// <summary>Adds the daily data.</summary>
        /// <param name="theData">The data.</param>
        /// <exception cref="ArgumentNullException">theData - must not be null</exception>
        public void AddDailyData(Covid19DailyData theData)
        {
            if (theData == null)
            {
                throw new ArgumentNullException(nameof(theData), "must not be null");
            }

            this.Covid19Data.Add(theData);
        }

        public override string ToString()
        {
            var finalString = "";
            foreach (var dailyData in this.Covid19Data)
            {
                finalString += dailyData + Environment.NewLine;
            }

            return finalString;
        }

        #endregion
    }
}