﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Covid19Analysis.Model;

namespace Covid19Analysis.ViewModel
{
    class DataFormatter
    {
        public Covid19DataCollection DataToFormat { get; set; }

        #region Constructor

        public DataFormatter(Covid19DataCollection dataToFormat)
        {
            DataToFormat = dataToFormat ?? throw new ArgumentNullException(nameof(dataToFormat));
        }

        #endregion

        #region Methods

        public string FindGeorgiaData()
        {
            Covid19DataCollection aCollection = new Covid19DataCollection();
            foreach (Covid19DailyData dailyData in this.DataToFormat)
            {
                if (dailyData.State.Equals(StateAbbreviations.GA))
                {
                    aCollection.AddDailyData(dailyData);
                }
            }

            return "Georgia Data" + System.Environment.NewLine + aCollection.ToString();
        }

        #endregion

    }
}
