﻿using System;

namespace Covid19Analysis.Model
{
    internal class Covid19DailyData
    {
        #region Methods

        public override string ToString()
        {
            return
                $"On {DataDate} in {State}: Positive Tests= {PositiveIncrease} Negative Test= {NegativeIncrease} Deaths= {DeathIncrease} Hospitalized= {HospitalizedIncrease}";
        }

        #endregion

        #region Properties

        public DateTime DataDate { get; set; }
        public StateAbbreviations? State { get; set; }
        public int PositiveIncrease { get; set; }
        public int NegativeIncrease { get; set; }
        public int DeathIncrease { get; set; }
        public int HospitalizedIncrease { get; set; }

        #endregion

        #region Constructors

        public Covid19DailyData()
        {
            DataDate = DateTime.MinValue;
            State = null;
            PositiveIncrease = 0;
            NegativeIncrease = 0;
            DeathIncrease = 0;
            HospitalizedIncrease = 0;
        }

        public Covid19DailyData(DateTime dataDate, StateAbbreviations state, int positiveIncrease, int negativeIncrease,
            int deathIncrease, int hospitalizedIncrease)
        {
            DataDate = dataDate;
            State = state;
            PositiveIncrease = positiveIncrease;
            NegativeIncrease = negativeIncrease;
            DeathIncrease = deathIncrease;
            HospitalizedIncrease = hospitalizedIncrease;
        }

        #endregion
    }
}