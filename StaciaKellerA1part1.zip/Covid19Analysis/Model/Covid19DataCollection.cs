﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Covid19Analysis.Model
{
    class Covid19DataCollection : IEnumerable
    {
        #region Properties

        public List<Covid19DailyData> Covid19Data { get; set; }

        #endregion

        #region Constructors

        public Covid19DataCollection()
        {
            this.Covid19Data = new List<Covid19DailyData>();
        }

        public Covid19DataCollection(List<Covid19DailyData> covid19Data)
        {
            Covid19Data = covid19Data;
        }

        #endregion

        #region Methods

        public void AddDailyData(Covid19DailyData theData)
        {
            if (theData == null)
            {
                throw new ArgumentNullException(nameof(theData), "must not be null");
            }
            else
            {
                this.Covid19Data.Add(theData);
            }
        }

        public override string ToString()
        {
            string finalString = "";
            foreach (var dailyData in this.Covid19Data)
            {
                finalString += dailyData.ToString() + System.Environment.NewLine;
            }
            return finalString;
        }

        #endregion

        public IEnumerator GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }
    }
}
