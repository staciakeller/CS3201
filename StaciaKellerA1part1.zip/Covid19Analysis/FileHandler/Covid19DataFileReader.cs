﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.UI.Xaml.Automation;
using Windows.UI.Xaml.Shapes;
using Covid19Analysis.Model;

namespace Covid19Analysis.FileHandler
{
    class Covid19DataFileReader
    {
        public StorageFile StorageFile { get; set; }
        public Covid19DataCollection LoadedData { get; }

        public Covid19DataFileReader(StorageFile storageFile)
        {
            this.StorageFile = storageFile ?? throw new ArgumentNullException(nameof(storageFile));
            this.LoadedData = new Covid19DataCollection();
        }
        
        public async void ReadFile()
        {
            var allText = await Windows.Storage.FileIO.ReadTextAsync(this.StorageFile);
            string modifiedText = allText.Replace("\r", "");

            string[] lines = modifiedText.Split("\n");

            //IList<string> lines = await Windows.Storage.FileIO.ReadLinesAsync(this.StorageFile);
            
            foreach (var aLine in lines)
            {
                if (!aLine.StartsWith("2020")) continue;
                string[] aDataSet = aLine.Split(",");
                DateTime date = DateTime.ParseExact(aDataSet.GetValue(0).ToString(), "yyyymmdd", CultureInfo.InvariantCulture);
                StateAbbreviations state = Enum.Parse<StateAbbreviations>(aDataSet.GetValue(1).ToString());
                int posInc = Int32.Parse(aDataSet.GetValue(2).ToString());
                int negInc = Int32.Parse(aDataSet.GetValue(3).ToString());
                int deaths = Int32.Parse(aDataSet.GetValue(4).ToString());
                int hospital = Int32.Parse(aDataSet.GetValue(5).ToString());

                Covid19DailyData dailyData = new Covid19DailyData(date, state, posInc, negInc, deaths, hospital);
                this.LoadedData.AddDailyData(dailyData);

            }

        }
    }
}
